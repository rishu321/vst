module.exports = {
    adminOnly:             require('./adminOnly'),
    adminOnlyConditional:  require('./adminOnlyConditional'),
    bindContext:           require('./bindContext'),
    errorHandler:          require('./errorHandler'),
    groupOnly:             require('./groupOnly'),
    skipNonTextualMessage: require('./skipNonTextualMessage'),
};