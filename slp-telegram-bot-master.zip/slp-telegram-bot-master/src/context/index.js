module.exports = {
    account:   require('../context/account'),
    addresses: require('../context/addresses'),
    scheduler: require('../context/scheduler'),
    settings:  require('../context/settings'),
};