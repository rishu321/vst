module.exports = {
    cmdAdmin:     require('./cmdAdmin'),
    cmdAirdrop:   require('./cmdAirdrop'),
    cmdAmount:    require('./cmdAmount'),
    cmdClear:     require('./cmdClear'),
    cmdInfo:      require('./cmdInfo'),
    cmdList:      require('./cmdList'),
    cmdParty:     require('./cmdParty'),
    cmdRegister:  require('./cmdRegister'),
    cmdToken:     require('./cmdToken'),
    cmdWithdraw:  require('./cmdWithdraw'),
};